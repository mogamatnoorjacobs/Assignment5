package Assignment5;

/**
 * Created by fatimam on 2016-04-05.
 */
public interface Location
{
    public void setAddress(int num,String road,String area);
    public String getAddress();
}
