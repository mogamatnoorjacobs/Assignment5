package Assignment5;

/**
 * Created by fatimam on 2016-04-05.
 */
public class Catalog
{
    private static String type1="Rent movies only";
    private static String type2="Rent movies and games";

    private String catalogSelection="";

    public Catalog()
    {

    }
    public Catalog(int cat)
    {
        if(cat==1) {
            catalogSelection = type1;
        }
        else {
            catalogSelection = type2;
        }
    }

    public void setCatalog(int cat)
    {
        if(cat==1)
            catalogSelection=type1;
        else
            catalogSelection=type2;

    }

    public String getCatalogSelection()
    {
        return catalogSelection;
    }



}
