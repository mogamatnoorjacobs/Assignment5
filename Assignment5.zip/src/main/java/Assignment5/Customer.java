package Assignment5;

/**
 * Created by fatimam on 2016-04-04.
 */
public class Customer extends AccountType implements Person
{
    private String firstName;
    private String lastName;
    private int identityNumber;
    private String physicalAddress;
    private int houseNumber;
    private String road;
    private String area;

    private String uName;
    private String passw;

    public Customer() {
    }

    public Customer(String name,String sName,int id,String physicalAddress,int houseNumber,String road,String area,String memberShip, String uName,String passw)
    {
        firstName=name;
        lastName=sName;
        identityNumber=id;
        this.houseNumber = houseNumber;
        this.road = road;
        this.area = area;
        this.uName=uName;
        this.passw=passw;
        setMemberDiscount(memberShip);

    }

    public void setName(String name)
    {
        firstName=name;
    }

    public String name() {

        return firstName;
    }

    public void setSurname(String sName)

    {
        lastName=sName;
    }
    public String surname() {

        return lastName;
    }

    public void setID(int id)
    {
        identityNumber=id;
    }


    public int idNumber() {

        return identityNumber;
    }

    public void setAddress(int houseNum,String road,String area)
    {
        this.houseNumber = houseNum;
        this.road = road;
        this.area = area;
    }

    public String getAddress()
    {
        physicalAddress= this.houseNumber+" "+road+" "+area;

        return physicalAddress;
    }

    public void setMemberShip(String memberShip)
    {
       setMemberDiscount(memberShip);
    }

    public double discount()

    {
        return getMembershipDiscount();
    }

    public void setUsername(String uName)
    {
        this.uName=uName;
    }


    public String username() {

        return uName;
    }

    public void setPassword(String passw)
    {
        this.passw=passw;
    }
    public String password() {
        return passw;
    }

    public String toString()
    {
        String customerReport= name()+" "+surname() +" "+idNumber()+" "+getAddress()+" "+getMembershipDiscount()+" "+username()+" "+password();
        return customerReport;
    }
}

    /*





    public String name(String firstName)
    {
        this.firstName=firstName;
        return this.firstName;
    }
    public String surname(String lastName)
    {
        this.lastName=lastName;
        return this.lastName;
    }
    public int idNumber(int identityNumber)
    {
        this.identityNumber=identityNumber;
        return this.identityNumber;
    }
    public String address(String physicalAddress)
    {
        this.physicalAddress=physicalAddress;
        return this.physicalAddress;
    }
    public String username(String uName)
    {
        this.uName=uName;
        return this.uName;
    }
    public String password(String passw)
    {
        this.passw=passw;
        return this.passw;
    }
*/

