package Assignment5;

/**
 * Created by fatimam on 2016-04-04.
 */
public interface Person extends Location
{
    public void setName(String name);
    public void setSurname(String sName);
    public void setID(int id);
    public void setUsername(String uName);
    public void setPassword(String passw);
    public String name();
    public String surname();
    public int idNumber();
    public void setAddress(int num,String road,String area);
    public String getAddress();
    public String username();
    public String password();
  ;

}

