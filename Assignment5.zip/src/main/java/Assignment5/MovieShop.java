package Assignment5;

/**
 * Created by fatimam on 2016-04-05.
 */
public class MovieShop implements Location
{
    private String physicalAddress;
    private int houseNumber;
    private String road;
    private String area;

    private String shopName;

    Catalog catalog=new Catalog();

    private int catNum;

    public MovieShop(){}

    public MovieShop(String shopName,int houseNum,String road,String area,int catNum)
    {
        this.shopName=shopName;
        this.houseNumber = houseNumber;
        this.road = road;
        this.area = area;
        catalog.setCatalog(catNum);

    }

    public void setName(String shopName)
    {
        this.shopName=shopName;
    }

    public String getShopName()
    {
        return shopName;
    }


    public void setAddress(int houseNum,String road,String area)
    {
        this.houseNumber = houseNum;
        this.road = road;
        this.area = area;
    }

    public String getAddress()
    {
        physicalAddress= this.houseNumber+" "+road+" "+area;

        return physicalAddress;
    }

    public void setCatalogs(int catNum)
    {
        catalog.setCatalog(catNum);
    }

    public String geCatSelection()
    {
        return catalog.getCatalogSelection();
    }

}
