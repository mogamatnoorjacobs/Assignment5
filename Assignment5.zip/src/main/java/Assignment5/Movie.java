package Assignment5;

/**
 * Created by fatimam on 2016-04-05.
 */
public class Movie extends MovieGendre implements ProductInterface
{
    private String movieName;
    private int gendre;
    private double moviePrice=0.00;

    public Movie(){}

    public Movie(String movieName,int gendre,double moviePrice)
    {
        this.movieName=movieName;
        this.gendre=gendre;
        this.moviePrice=moviePrice;

    }

    public void setProductName(String movieName)
    {
        this.movieName=movieName;
    }

    public String productName()
    {
        return movieName;
    }
    public void setGendreTypes(int gendre)
    {
        setGendreType(gendre);
    }

    public String getGendres()

    {
        return getGendre();
    }

    public void setPrice(double price)
    {
        moviePrice=price;
    }

    public double price()
    {
        return this.moviePrice;
    }

}
