package Assignment5;

/**
 * Created by fatimam on 2016-04-05.
 */
public class Booking
{
    //Name of Customer(username),MovieShop,Discount from Account type movie or game, Staff(username) who booked out

    public Booking(){}

    private Customer customer;
    private Game game;
    private Movie movie;
    private MovieShop movieShop;
    private Staff staff;
    private double total;

    public Booking(Customer custom,Game game,Movie movie,MovieShop movieShop,Staff staff)
    {
        this.customer=customer;
        this.game=game;
        this.movie=movie;
        this.movieShop=movieShop;
        this.staff=staff;

    }

    public double calculateTotal()
    {
        total=(movie.price()+game.price())*customer.getMembershipDiscount();
        return total;
    }


    public String toString()
    {
        String rental;
        rental="Customer: "+customer.name()+" "+"Movie: "+movie.productName()+" "+"Game: "+ game.productName()+" "+"Movie Shop"+movieShop.getShopName()+" "+ "Staff: "+staff.username()+" "+"Total: R"+calculateTotal()+" ";
        return rental;
    }



}
