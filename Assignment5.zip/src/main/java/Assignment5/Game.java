package Assignment5;

/**
 * Created by fatimam on 2016-04-05.
 */
public class Game extends GameGendre implements ProductInterface
{
    private String gameName;
    private int gendre;
    private double gamePrice=0.00;

    public Game(){}

    public Game(String gameName,int gendre,double gamePrice)
    {
        this.gameName=gameName;
        this.gendre=gendre;
        this.gamePrice=gamePrice;

    }

    public void setProductName(String gameName)
    {
        this.gameName=gameName;
    }

    public String productName()
    {
        return gameName;
    }
    public void setGendreTypes(int gendre)
    {
        setGendreType(gendre);
    }

    public String getGendres()

    {
        return getGendre();
    }

    public void setPrice(double price)
    {
        gamePrice=price;
    }

    public double price()
    {
        return this.gamePrice;
    }

}
