package Assignment5;

/**
 * Created by fatimam on 2016-04-05.
 */
public class GameGendre implements GendreInterface
{
    public GameGendre ()
    {}

    private String gendre;

    public void setGendreType(int gendreNum)
    {
        if(gendreNum==1)
        {
            gendre="Action";

        }

        else
        gendre="Horror";

    }

    public String getGendre()
    {
        return gendre;
    }

}
