package Assignment5;

/**
 * Created by fatimam on 2016-04-05.
 */
public class AccountType extends Discount
{
    private String member;
    private double membership;

    public AccountType()
    {}


    public void memberType(int num)
    {
        if(num==1)
        {
            member="Silver";
        }

        else if(num==2)
        {
            member="Gold";
        }

        else if(num==3)
        {
            member="Platinum";
        }

        else
        {
            member="New";
        }
    }

    public String getMemberType()
    {
        return member;
    }


    public void setMemberDiscount(String membership)
    {


        if(membership.equalsIgnoreCase("Platinum"))
        {
            this.membership=getPlatinumClient();
        }
        else if(membership.equalsIgnoreCase("Gold"))
        {
            this.membership=getGoldClient();
        }
        else if(membership.equalsIgnoreCase("Silver"))
        {
            this.membership=getSilverClient();
        }
        else
        {
            this.membership=getNewClient();
        }

    }

    public double getMembershipDiscount()
    {
        return this.membership;
    }


}
