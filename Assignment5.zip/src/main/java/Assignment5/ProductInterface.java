package Assignment5;

/**
 * Created by fatimam on 2016-04-05.
 */
public interface ProductInterface
{
    public String productName();
    public double price();
}
