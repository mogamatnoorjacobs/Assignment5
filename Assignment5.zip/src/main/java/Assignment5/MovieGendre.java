package Assignment5;

/**
 * Created by fatimam on 2016-04-05.
 */
public class MovieGendre implements GendreInterface
{
    private String gendre;

    public MovieGendre(){}

    public void setGendreType(int gendreNum)
    {
        if(gendreNum==1)
        {
            gendre="Action";

        }
        else  if(gendreNum==2)
        {
            gendre="Comedy";

        }

        else
            gendre="Horror";
      }

    public String getGendre()
    {
        return gendre;
    }
}
