package Assignment5;

/**
 * Created by fatimam on 2016-04-05.
 */
public interface GendreInterface
{
    public void setGendreType(int gendre);
    public String getGendre();
}
