package Assignment5;

/**
 * Created by fatimam on 2016-04-04.
 */
 public class Staff implements Person
{
    private String firstName;
    private String lastName;
    private int identityNumber;
    private String physicalAddress;
    private int houseNumber;
    private String road;
    private String area;
    private String uName;
    private String passw;

    public Staff()
    {    }

    public Staff(String name,String sName,int id,String physicalAddress,int houseNumber,String road,String area,String uName,String passw)
    {
        firstName=name;
        lastName=sName;
        identityNumber=id;
        this.houseNumber = houseNumber;
        this.road = road;
        this.area = area;
        this.uName=uName;
        this.passw=passw;
    }

    public void setName(String name)
    {
        firstName=name;
    }

    public String name() {

        return firstName;
    }

    public void setSurname(String sName)
    {
        lastName=sName;
    }
    public String surname() {

        return lastName;
    }

    public void setID(int id)
    {
        identityNumber=id;
    }


    public int idNumber() {

        return identityNumber;
    }

    public void setAddress(int houseNum,String road,String area)
    {
        this.houseNumber = houseNum;
        this.road = road;
        this.area = area;
    }

    public String getAddress()
    {
        physicalAddress= this.houseNumber+" "+road+" "+area;

        return physicalAddress;
    }



    public void setUsername(String uName)
    {
        this.uName=uName;
    }


    public String username() {

        return uName;
    }

    public void setPassword(String passw)
    {
        this.passw=passw;
    }
    public String password() {
        return passw;
    }

    public String toString()
    {
        String staffReport= name()+" "+surname() +" "+idNumber()+" "+getAddress()+" "+username()+" "+password();
        return staffReport;
    }


}
