package Assignment5;

import junit.framework.TestCase;

/**
 * Created by fatimam on 2016-04-07.
 */
public class BookingTest extends TestCase {

    public void testCalculateTotal() throws Exception
    {
        String firstName="Mogamat";
        String lastName="Jacobs";
        int identityNumber=12345678;
        int houseNumber = 5;
        String road = "hazendal rd";
        String area = "Athlone";
        String memberShip="New";
        String uName="noor";
        String passw="noor";

        Customer customer=new Customer();
        customer.setName(firstName);
        customer.setSurname(lastName);
        customer.setID(identityNumber);
        customer.setAddress(houseNumber,road,area);
        customer.setMemberShip(memberShip);
        customer.setUsername(uName);
        customer.setPassword(passw);

        Game game=new Game();

        game.setProductName("Speed");
        String gameName=game.productName();

        game.setGendreTypes(1);
        String gameGendre=game.getGendres();

        game.setPrice(30.00);
        double gamePrice=game.price();

        Movie movie=new Movie();

        movie.setProductName("Matrix");
        String movieName=movie.productName();

        movie.setGendreType(1);
        String movieGendre=movie.getGendres();

        movie.setPrice(20.00);
        double moviePrice=movie.price();

        MovieShop shop=new MovieShop();
        String shopName="Athlone";

        shop.setName(shopName);

        String nameShop= shop.getShopName();

        int shpNumber = 5;
        String street = "hazendal rd";
        String suburb = "Athlone";

        Location shops=new MovieShop();

        shops.setAddress(houseNumber,road,area);
        String address=shops.getAddress();

        String fName="noor";
        String lName="Jacobs";
        int idNumber=12345678;
        int hNumber = 5;
        String streetA = "3rd rd";
        String  subAddress = "cape town";
        String userName="mogamat";
        String passwrd="mogamat";



        Person staff=new Staff();
        staff.setName(fName);
        staff.setSurname(lName);
        staff.setID(idNumber);
        staff.setAddress(hNumber,streetA,subAddress);
        staff.setUsername(userName);
        staff.setPassword(passwrd);


        String staffToString= staff.toString();




    }

    public void testToString() throws Exception
    {
        String firstName="Mogamat";
        String lastName="Jacobs";
        int identityNumber=12345678;
        int houseNumber = 5;
        String road = "hazendal rd";
        String area = "Athlone";
        String memberShip="New";
        String uName="noor";
        String passw="noor";

        Customer customer=new Customer();
        customer.setName(firstName);
        customer.setSurname(lastName);
        customer.setID(identityNumber);
        customer.setAddress(houseNumber,road,area);
        customer.setMemberShip(memberShip);
        customer.setUsername(uName);
        customer.setPassword(passw);

        Game game=new Game();

        game.setProductName("Speed");
        String gameName=game.productName();

        game.setGendreTypes(1);
        String gameGendre=game.getGendres();

        game.setPrice(30.00);
        double gamePrice=game.price();

        Movie movie=new Movie();

        movie.setProductName("Matrix");
        String movieName=movie.productName();

        movie.setGendreType(1);
        String movieGendre=movie.getGendres();

        movie.setPrice(20.00);
        double moviePrice=movie.price();

        MovieShop shop=new MovieShop();
        String shopName="Athlone";

        shop.setName(shopName);

        String nameShop= shop.getShopName();

        int shpNumber = 5;
        String street = "hazendal rd";
        String suburb = "Athlone";

        Location shops=new MovieShop();

        shops.setAddress(houseNumber,road,area);
        String address=shops.getAddress();

        String fName="noor";
        String lName="Jacobs";
        int idNumber=12345678;
        int hNumber = 5;
        String streetA = "3rd rd";
        String  subAddress = "cape town";
        String userName="mogamat";
        String passwrd="mogamat";



        Person staff=new Staff();
        staff.setName(fName);
        staff.setSurname(lName);
        staff.setID(idNumber);
        staff.setAddress(hNumber,streetA,subAddress);
        staff.setUsername(userName);
        staff.setPassword(passwrd);


        String staffToString= staff.toString();

       // Booking booking=new Booking("Noor","Matrix","Street fighter","Atholon","Mogamat");
        //(Customer custom,Game game,Movie movie,MovieShop movieShop,Staff staff)

        //booking.toString();


    }
}