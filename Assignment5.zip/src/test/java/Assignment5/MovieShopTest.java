package Assignment5;

import junit.framework.TestCase;

/**
 * Created by fatimam on 2016-04-07.
 */
public class MovieShopTest extends TestCase {

    public void testSetName() throws Exception
    {
        MovieShop shop=new MovieShop();

        String shopName="Athlone";

        shop.setName(shopName);

        String expected= shop.getShopName();
        String result="Athlone";
        assertEquals(expected,result);

    }

    public void testSetAddress() throws Exception
    {
        int houseNumber = 5;
        String road = "hazendal rd";
        String area = "Athlone";

        Location shop=new MovieShop();

         shop.setAddress(houseNumber,road,area);
        String address=shop.getAddress();


        String expected=address;
        String result="5 hazendal rd Athlone";
        assertEquals(expected,result);

    }

    public void testSetCatalog() throws Exception
    {

        int cat=1;
        MovieShop shop=new MovieShop();
        shop.setCatalogs(cat);

        String expected=shop.geCatSelection();
        String result="Rent movies only";
        assertEquals(expected,result);



    }
}