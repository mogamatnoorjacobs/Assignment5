package Assignment5;

import junit.framework.TestCase;

/**
 * Created by fatimam on 2016-04-07.
 */
public class AccountTypeTest extends TestCase {

    public void testMemberType() throws Exception
    {

        AccountType accountType=new AccountType();
        accountType.memberType(1);


        assertEquals(accountType.getMemberType(),"Silver");

    }

    public void testMemberType2() throws Exception
    {

        AccountType accountType=new AccountType();
        accountType.memberType(2);


        assertEquals(accountType.getMemberType(),"Gold");

    }

    public void testSetMemberDiscount() throws Exception
    {
        AccountType accountType=new AccountType();
        accountType.setMemberDiscount("Gold");

        assertEquals(accountType.getMembershipDiscount(),0.15);

    }

    public void testSetMemberDiscount2() throws Exception
    {
        AccountType accountType=new AccountType();
        accountType.setMemberDiscount("Silver");

        assertEquals(accountType.getMembershipDiscount(),0.10);

    }
}