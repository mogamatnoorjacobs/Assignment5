package Assignment5;

import junit.framework.TestCase;

/**
 * Created by fatimam on 2016-04-07.
 */
public class GameTest extends TestCase {

    public void testSetProductName() throws Exception
    {
        Game game=new Game();

        game.setProductName("Speed");
        String gameName=game.productName();

        assertEquals(gameName,"Speed");

    }

    public void testSetProductName2() throws Exception
    {
        Game game=new Game();

        game.setProductName("Crashband");
        String gameName=game.productName();

        assertEquals(gameName,"Crashband");

    }

    public void testSetGendreType() throws Exception
    {

        Game game=new Game();

        game.setGendreTypes(1);
        String gameGendre=game.getGendres();

        assertEquals(gameGendre,"Action");

    }

    public void testSetGendreType2() throws Exception
    {

        Game game=new Game();

        game.setGendreTypes(2);
        String gameGendre=game.getGendres();

        assertEquals(gameGendre,"Horror");

    }

    public void testSetPrice() throws Exception
    {
        Game game=new Game();
        game.setPrice(30.00);
        double gamePrice=game.price();

        assertEquals(gamePrice,30.00);

    }

    public void testSetPrice2() throws Exception
    {
        Game game=new Game();
        game.setPrice(10.00);
        double gamePrice=game.price();

        assertEquals(gamePrice,10.00);

    }
}