package Assignment5;

import junit.framework.TestCase;

/**
 * Created by fatimam on 2016-04-07.
 */
public class DiscountTest extends TestCase {

    public void testGetPlatinumClient() throws Exception
    {
        Discount discount=new Discount();

        assertEquals(discount.getPlatinumClient(),0.20);

    }

    public void testGetGoldClient() throws Exception
    {
        Discount discount=new Discount();

        assertEquals(discount.getGoldClient(),0.15);

    }

    public void testGetSilverClient() throws Exception
    {
        Discount discount=new Discount();

        assertEquals(discount.getSilverClient(),0.10);

    }

    public void testGetNewClient() throws Exception
    {
        Discount discount=new Discount();

        assertEquals(discount.getNewClient(),0.00);

    }
}