package Assignment5;

import junit.framework.TestCase;

/**
 * Created by fatimam on 2016-04-07.
 */
public class StaffTest extends TestCase {

    public void testSetName() throws Exception
    {
         String firstName="Noor";
        String lastName="Jacobs";
        int identityNumber=12345678;
        int houseNumber = 5;
        String road = "hazendal rd";
        String area = "Athlone";
        String uName="noor";
        String passw="noor";


        //Person staff=new Staff(firstName,lastName,identityNumber,houseNumber,road,area,uName,passw);
        Person staff=new Staff();
        staff.setName(firstName);
        staff.setSurname(lastName);
        staff.setID(identityNumber);
        staff.setAddress(houseNumber,road,area);
        staff.setUsername(uName);
        staff.setPassword(passw);


        String expected= staff.toString();
        String result="Noor Jacobs 12345678 5 hazendal rd Athlone noor noor";
        assertEquals(expected,result);
    }

    public void testSetName2() throws Exception
    {
        String firstName="Mogamat";
        String lastName="Jacobs";
        int identityNumber=12345678;
        int houseNumber = 5;
        String road = "hazendal rd";
        String area = "Athlone";
        String uName="noor";
        String passw="noor";


        //Person staff=new Staff(firstName,lastName,identityNumber,houseNumber,road,area,uName,passw);
        Person staff=new Staff();
        staff.setName(firstName);
        staff.setSurname(lastName);
        staff.setID(identityNumber);
        staff.setAddress(houseNumber,road,area);
        staff.setUsername(uName);
        staff.setPassword(passw);


        String expected= staff.toString();

        String result="Mogamat Jacobs 12345678 5 hazendal rd Athlone noor noor";
        assertEquals(expected,result);
    }
}