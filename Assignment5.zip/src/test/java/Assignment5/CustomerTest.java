package Assignment5;

import junit.framework.TestCase;

/**
 * Created by fatimam on 2016-04-07.
 */
public class CustomerTest extends TestCase {

    public void testSetName() throws Exception
    {
        String firstName="Mogamat";
        String lastName="Jacobs";
        int identityNumber=12345678;
        int houseNumber = 5;
        String road = "hazendal rd";
        String area = "Athlone";
        String memberShip="New";
        String uName="noor";
        String passw="noor";


        //Customer customer=new Customer(firstName,lastName,identityNumber,houseNumber,road,area,uName,passw);
        Customer customer=new Customer();
        customer.setName(firstName);
        customer.setSurname(lastName);
        customer.setID(identityNumber);
        customer.setAddress(houseNumber,road,area);
        customer.setMemberShip(memberShip);
        customer.setUsername(uName);
        customer.setPassword(passw);


        String expected= "Mogamat Jacobs 12345678 5 hazendal rd Athlone 0.0 noor noor";
        String result=customer.toString();
        assertEquals(expected,result);
    }

    public void testSetName2() throws Exception {
        String firstName = "Noor";
        String lastName = "Jacobs";
        int identityNumber = 12345678;
        int houseNumber = 5;
        String road = "hazendal rd";
        String area = "Athlone";
        String memberShip = "New";
        String uName = "noor";
        String passw = "noor";


        //Customer customer=new Customer(firstName,lastName,identityNumber,houseNumber,road,area,uName,passw);
        Customer customer = new Customer();
        customer.setName(firstName);
        customer.setSurname(lastName);
        customer.setID(identityNumber);
        customer.setAddress(houseNumber, road, area);
        customer.setMemberShip(memberShip);
        customer.setUsername(uName);
        customer.setPassword(passw);


        String expected = "Noor Jacobs 12345678 5 hazendal rd Athlone 0.0 noor noor";
        String result = customer.toString();
        assertEquals(expected, result);
    }
}