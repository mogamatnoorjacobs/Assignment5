package Assignment5;

import junit.framework.TestCase;

/**
 * Created by fatimam on 2016-04-07.
 */
public class GameGendreTest extends TestCase {

    public void testSetGendreType() throws Exception
    {
        GendreInterface gameGendre= new GameGendre();

        int num=1;

        gameGendre.setGendreType(1);

        String expected= gameGendre.getGendre();
        String result="Action";
        assertEquals(expected,result);

    }

    public void testSetGendreType2() throws Exception
    {
        GendreInterface gameGendre= new GameGendre();


        gameGendre.setGendreType(2);

        String expected= gameGendre.getGendre();
        String result="Horror";
        assertEquals(expected,result);

    }

}