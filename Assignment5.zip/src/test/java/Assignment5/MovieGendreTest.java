package Assignment5;

import junit.framework.TestCase;

/**
 * Created by fatimam on 2016-04-07.
 */
public class MovieGendreTest extends TestCase {

    public void testSetGendreType() throws Exception
    {
        MovieGendre gendreSelect=new MovieGendre();

       int num=1;

        gendreSelect.setGendreType(1);

        String expected= gendreSelect.getGendre();
        String result="Action";
        assertEquals(expected,result);

    }
}