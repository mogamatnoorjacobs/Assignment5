package Assignment5;

import junit.framework.TestCase;

/**
 * Created by fatimam on 2016-04-07.
 */
public class MovieTest extends TestCase {

    public void testSetProductName() throws Exception
    {
        Movie movie=new Movie();

        movie.setProductName("Matrix");
        String movieName=movie.productName();

        assertEquals(movieName,"Matrix");

    }

    public void testSetProductName2() throws Exception
    {
        Movie movie=new Movie();

        movie.setProductName("badboys");
        String movieName=movie.productName();

        assertEquals(movieName,"badboys");

    }




    public void testSetGendreType() throws Exception
    {
        Movie movie=new Movie();

        movie.setGendreType(1);
        String movieGendre=movie.getGendres();

        assertEquals(movieGendre,"Action");

    }

    public void testSetGendreType2() throws Exception
    {
        Movie movie=new Movie();

        movie.setGendreType(2);
        String movieGendre=movie.getGendres();

        assertEquals(movieGendre,"Comedy");

    }




    public void testSetPrice() throws Exception
    {
        Movie movie=new Movie();
        movie.setPrice(20.00);
        double moviePrice=movie.price();

        assertEquals(moviePrice,20.00);

    }
    public void testSetPrice2() throws Exception
    {
        Movie movie=new Movie();
        movie.setPrice(2.00);
        double moviePrice=movie.price();

        assertEquals(moviePrice,2.00);

    }

}